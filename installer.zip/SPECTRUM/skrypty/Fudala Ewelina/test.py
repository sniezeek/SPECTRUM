from lxml import etree
f = open("FROM.xml","r",encoding='utf8')
lines = open(filename).read().splitlines()
tree = etree.parse(f)
print(etree.tostring(tree))