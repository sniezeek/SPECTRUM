import json 

def initializeK(temp):
    kontrahent = {
        'EKSPORT':"",
        'EKSPORT_ENOVA':"",
        'FINALNY':"",
        'POWIAZANY_UOV':"",
        'ADRESY':[{
            'STATUS':"",
            'AKRONIM':"",
            'NAZWA1':"",
            'KRAJ':"",
            'WOJEWODZTWO':"",
            'POWIAT':"",
            'GMINA':"",
            'ULICA':"",
            'NR_DOMU':"",
            'NR_LOKALU':"",
            'MIASTO':"",
            'KOD_POCZTOWY':"",
            'POCZTA':"",
            'NIP':""
            }
        ]
    }
    kontrahent['EKSPORT']="krajowy"
    kontrahent['EKSPORT_ENOVA']="krajowy"
    kontrahent['FINALNY']="Nie"
    kontrahent['POWIAZANY_UOV']="Nie"
    kontrahent['ADRESY'][0]['STATUS']="aktualny"
    kontrahent['ADRESY'][0]['AKRONIM']=temp['id']
    kontrahent['ADRESY'][0]['NAZWA1']=temp['nazwa']
    #kontrahent['ADRESY'][0]['KRAJ']=
    #kontrahent['ADRESY'][0]['WOJEWODZTWO']=
    #kontrahent['ADRESY'][0]['POWIAT']=
    #kontrahent['ADRESY'][0]['GMINA']=
    kontrahent['ADRESY'][0]['ULICA']=temp['ulica']
    kontrahent['ADRESY'][0]['NR_DOMU']=temp['dom'].replace(" I ",',')
    kontrahent['ADRESY'][0]['NR_LOKALU']=temp['lokal']
    kontrahent['ADRESY'][0]['MIASTO']=temp['miejscowosc']
    kontrahent['ADRESY'][0]['KOD_POCZTOWY']=temp['kodpocz']
    #kontrahent['ADRESY'][0]['POCZTA']=
    kontrahent['ADRESY'][0]['NIP']=temp['nip'].replace('-','').replace(' ','')
    return kontrahent

def initializeR(temp):
    rejestr ={
        'DATA_WYSTAWIENIA':"",
        'DATA_SPRZEDAZY':"",
        'TERMIN':"",
        'NUMER':"",
        'KOREKTA':"",
        'KOREKTA_NUMER':"",
        'FISKALNA':"",
        'DETALICZNA':"",
        'EKSPORT':"",
        'EKSPORT_ENOVA':"",
        'FINALNY':"",
        'TYP_PODMIOTU':"",
        'PODMIOT':"",
        'NAZWA1':"",
        'NIP':"",
        'KRAJ':"",
        'WOJEWODZTWO':"",
        'POWIAT':"",
        'GMINA':"",
        'ULICA':"",
        'NR_DOMU':"",
        'NR_LOKALU':"",
        'MIASTO':"",
        'KOD_POCZTOWY':"",
        'POCZTA':"",
        'OPIS':"",
        'MPP':"",
        'FORMA_PLATNOSCI':"",
        'POZYCJE':[{
            'STAWKA_VAT':"",
            'STATUS_VAT':"",
            'NETTO':"",
            'VAT':"",
            'NETTO_SYS':"",
            'VAT_SYS':"",
            'NETTO_SYS2':"",
            'VAT_SYS2':"",
            'RODZAJ_SPRZEDAZY':""
            }
        ],
        'PLATNOSCI':[{
            'TERMIN_PLAT':"",
            'FORMA_PLATNOSCI_PLAT':"",
            'KWOTA_PLAT':"",
            'KWOTA_PLN_PLAT':"",
            'WALUTA_PLAT':"",
            'WALUTA_DOK':"",
            'KIERUNEK':""
            }
        ],
        'KODY_JPK':[
        ]
    }

    #
    #rejestr = rejestr.copy()
    rejestr['DATA_WYSTAWIENIA']=temp['data']
    rejestr['DATA_SPRZEDAZY']=temp['datasp']
    rejestr['TERMIN']=temp['data']
    rejestr['NUMER']=temp['FK nazwa']
    #rejestr['KOREKTA']="Nie"
    #rejestr['KOREKTA_NUMER']=""
    #rejestr['FISKALNA']="Nie"
    #rejestr['DETALICZNA']="Nie"
    #rejestr['EKSPORT']="Nie"
    #rejestr['EKSPORT_ENOVA']="krajowy"
    #rejestr['FINALNY']="Nie"
    rejestr['TYP_PODMIOTU']="kontrahent"
    rejestr['PODMIOT']=temp['khid']
    rejestr['NIP']=temp['khnip'].replace('-','')
    rejestr['OPIS']="usługa sprzątania"
    #rejestr['MPP']="Nie"
    rejestr['FORMA_PLATNOSCI']="Gotówka"

    rejestr['POZYCJE'][0]['STATUS_VAT']="opodatkowana"
    netto = 0
    vat = 0

    for i in range(5):
        numer_rejestru='Rejestr'+str(i)
        if numer_rejestru in temp:
            if i > 0 :
                rejestr['POZYCJE'].append({
            'STAWKA_VAT':"",
            'STATUS_VAT':"",
            'NETTO':"",
            'VAT':"",
            'NETTO_SYS':"",
            'VAT_SYS':"",
            'NETTO_SYS2':"",
            'VAT_SYS2':"",
            'RODZAJ_SPRZEDAZY':""
            })
            rejestr['POZYCJE'][i]['NETTO']=temp[numer_rejestru]['netto']
            rejestr['POZYCJE'][i]['NETTO_SYS']=temp[numer_rejestru]['netto']
            rejestr['POZYCJE'][i]['NETTO_SYS2']=temp[numer_rejestru]['netto']
    
    
            rejestr['POZYCJE'][i]['VAT']=temp[numer_rejestru]['vat']
            rejestr['POZYCJE'][i]['VAT_SYS']=temp[numer_rejestru]['vat']
            rejestr['POZYCJE'][i]['VAT_SYS2']=temp[numer_rejestru]['vat']
            rejestr['POZYCJE'][i]['STAWKA_VAT']=temp[numer_rejestru]['stawka']
            rejestr['POZYCJE'][i]['RODZAJ_SPRZEDAZY']="usługa"
    
    rejestr['PLATNOSCI'][0]['KWOTA_PLAT']=temp['dozaplaty']
    rejestr['PLATNOSCI'][0]['KWOTA_PLN_PLAT']=temp['dozaplaty']       
    rejestr['PLATNOSCI'][0]['TERMIN_PLAT']=temp['plattermin']
    if temp['forma_platnosci'][0:7] == "przelew":
        rejestr['PLATNOSCI'][0]['FORMA_PLATNOSCI_PLAT']="przelew"
    else:
        rejestr['PLATNOSCI'][0]['FORMA_PLATNOSCI_PLAT']=temp['forma_platnosci']

    #rejestr['PLATNOSCI'][0]['WALUTA_PLAT']=""
    #rejestr['PLATNOSCI'][0]['WALUTA_DOK']=""
    rejestr['PLATNOSCI'][0]['KIERUNEK']="przychód"

    #GTU = temp['JPK_V7'].split(',')
    #for i in range(len(GTU)):
    #    rejestr['KODY_JPK'].append(dict({'KOD':GTU[i]}))
    

    json_formatted_str = json.dumps(rejestr, indent=2)
    print(json_formatted_str)
    return rejestr
    
    
    


    
    
    #print(json.dumps(kontrahenci,indent=3,ensure_ascii=False))
    #print(json.dumps(rejestry,indent=3,ensure_ascii=False))
    print("Initialize Ok")
    return kontrahent, rejestr
    #return kontrahenci, rejestry

def load_data(kontrahent,rejestr):
    kontrahenci=[]
    rejestry=[]

    with open("FROMJSON.txt",'r') as f:
        data = f.read()
    obj=json.loads(data)


    return kontrahenci, rejestry


#TODO modul z textu na klase
#TODO kopiowanie podlist
#TODO xml z jsona
#numer rejestru inaczej

########################
#wystarczy tylko akronim i nie muszą byc niewypelniane dane w xml