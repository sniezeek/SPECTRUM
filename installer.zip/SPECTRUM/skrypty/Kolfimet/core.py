import openpyxl
import numpy as np
import os
import json
from lxml import etree

#python -m pip install pywin32
#import win32com.client as win32
#fname = "A.xls"
#excel = win32.gencache.EnsureDispatch('Excel.Application')
#wb = excel.Workbooks.Open(fname)

#wb.SaveAs(fname+"x", FileFormat = 51)    #FileFormat = 51 is for .xlsx extension
#wb.Close()                               #FileFormat = 56 is for .xls extension
#excel.Application.Quit()


def initializeK(temp):
    print("kontrahent initialize")
    kontrahent = {
        'EKSPORT':"",
        'EKSPORT_ENOVA':"",
        'FINALNY':"",
        'POWIAZANY_UOV':"",
        'ADRESY':[{
            'STATUS':"",
            'AKRONIM':"",
            'NAZWA1':"",
            'KRAJ':"",
            'WOJEWODZTWO':"",
            'POWIAT':"",
            'GMINA':"",
            'ULICA':"",
            'NR_DOMU':"",
            'NR_LOKALU':"",
            'MIASTO':"",
            'KOD_POCZTOWY':"",
            'POCZTA':"",
            'NIP':""
            }
        ]
    }
    kontrahent['EKSPORT']="krajowy"
    kontrahent['EKSPORT_ENOVA']="krajowy"
    if temp['NIP'] is None:
        temp['NIP']=''
        kontrahent['ADRESY'][0]['NIP']=''
        kontrahent['ADRESY'][0]['AKRONIM']=str(temp['Nabywca'][:21])
    else:
        kontrahent['ADRESY'][0]['AKRONIM']=str(temp['NIP'])+':'+str(temp['Nabywca'][:8])
        kontrahent['ADRESY'][0]['NIP']=temp['NIP']
    kontrahent['FINALNY']="Nie"
    kontrahent['POWIAZANY_UOV']="Nie"
    kontrahent['ADRESY'][0]['STATUS']="aktualny"
    kontrahent['ADRESY'][0]['NAZWA1']=temp['Nabywca']
    #kontrahent['ADRESY'][0]['KRAJ']=
    #kontrahent['ADRESY'][0]['WOJEWODZTWO']=
    #kontrahent['ADRESY'][0]['POWIAT']=
    if temp['Gmina'] is None:
        kontrahent['ADRESY'][0]['GMINA']=""
    else:
        kontrahent['ADRESY'][0]['GMINA']=temp['Gmina']
    kontrahent['ADRESY'][0]['ULICA']=" ".join(temp['Adres'].split(',')[:-1])
    #kontrahent['ADRESY'][0]['NR_DOMU']=
    #kontrahent['ADRESY'][0]['NR_LOKALU']=
    kontrahent['ADRESY'][0]['MIASTO']=" ".join(temp['Adres'].split(',')[-1].split()[1:])
    kontrahent['ADRESY'][0]['KOD_POCZTOWY']=temp['Adres'].split(',')[-1].split()[0]
    #kontrahent['ADRESY'][0]['POCZTA']=
   
    return kontrahent

def initializeR(temp):
    print("rejestr initialize")
    rejestr ={
        'REJESTR':"",
        'DATA_WYSTAWIENIA':"",
        'DATA_SPRZEDAZY':"",
        'TERMIN':"",
        'NUMER':"",
        'KOREKTA':"",
        'KOREKTA_NUMER':"",
        'FISKALNA':"",
        'DETALICZNA':"",
        'EKSPORT':"",
        'EKSPORT_ENOVA':"",
        'FINALNY':"",
        'TYP_PODMIOTU':"",
        'PODMIOT':"",
        'NAZWA1':"",
        'NIP':"",
        'KRAJ':"",
        'WOJEWODZTWO':"",
        'POWIAT':"",
        'GMINA':"",
        'ULICA':"",
        'NR_DOMU':"",
        'NR_LOKALU':"",
        'MIASTO':"",
        'KOD_POCZTOWY':"",
        'POCZTA':"",
        'OPIS':"",
        'MPP':"",
        'FORMA_PLATNOSCI':"",
        'POZYCJE':[{
            'STAWKA_VAT':"",
            'STATUS_VAT':"",
            'NETTO':"",
            'VAT':"",
            'NETTO_SYS':"",
            'VAT_SYS':"",
            'NETTO_SYS2':"",
            'VAT_SYS2':"",
            'RODZAJ_SPRZEDAZY':""
            }
        ],
        'PLATNOSCI':[{
            'TERMIN_PLAT':"",
            'FORMA_PLATNOSCI_PLAT':"",
            'KWOTA_PLAT':"",
            'KWOTA_PLN_PLAT':"",
            'WALUTA_PLAT':"",
            'WALUTA_DOK':"",
            'KIERUNEK':""
            }
        ],
        'KODY_JPK':[
        ]
    }

    #
    #rejestr = rejestr.copy()
    if temp['Numer'][0:4]=="FVAT":
        rejestr['REJESTR']="SPT"
    if temp['Numer'][0:4]=="FPAR":
        rejestr['REJESTR']="SPFVP"
    rejestr['DATA_WYSTAWIENIA']=temp['Data wystawienia'].strftime("%Y-%m-%d")
    rejestr['DATA_SPRZEDAZY']=temp['Data sprzedaży'].strftime("%Y-%m-%d")
    rejestr['TERMIN']=temp['Termin płatności'].strftime("%Y-%m-%d")
    rejestr['NUMER']=temp['Numer']
    #rejestr['KOREKTA']="Nie"
    #rejestr['KOREKTA_NUMER']=""
    #rejestr['FISKALNA']="Nie"
    #rejestr['DETALICZNA']="Nie"
    #rejestr['EKSPORT']="Nie"
    #rejestr['EKSPORT_ENOVA']="krajowy"
    #rejestr['FINALNY']="Nie"
    rejestr['TYP_PODMIOTU']="kontrahent"
    if temp['NIP'] is None:
        #temp['NIP']=''
        rejestr['PODMIOT']=str(temp['Nabywca'][:21])
    else:
        rejestr['PODMIOT']=str(temp['NIP'])+':'+str(temp['Nabywca'][:8])
    rejestr['NIP']=temp['NIP']
    rejestr['OPIS']="sprzedaż towarów"
    if temp['Podzielona płatność']=="Zaznaczony":
        rejestr['MPP']="Tak"
        rejestr['KODY_JPK'].append(dict({'KOD':'MPP'}))
    if temp['Podzielona płatność']=="Niezaznaczony":
        rejestr['MPP']="Nie"
    rejestr['FORMA_PLATNOSCI']="Gotówka"
    netto = 0
    vat = 0
    rejestr['POZYCJE'][0]['STATUS_VAT']="opodatkowana"

    rejestr['POZYCJE'][0]['NETTO']=str(temp['Wartość netto'])
    rejestr['POZYCJE'][0]['NETTO_SYS']=str(temp['Wartość netto'])
    rejestr['POZYCJE'][0]['NETTO_SYS2']=str(temp['Wartość netto'])
    
    netto=temp['Wartość netto']

    rejestr['POZYCJE'][0]['VAT']=str(temp['Wartość VAT'])
    rejestr['POZYCJE'][0]['VAT_SYS']=str(temp['Wartość VAT'])
    rejestr['POZYCJE'][0]['VAT_SYS2']=str(temp['Wartość VAT'])
    
    vat = temp['Wartość VAT']

    rejestr['POZYCJE'][0]['STAWKA_VAT']=str(int(round(100*float(vat)/float(netto))))
    rejestr['POZYCJE'][0]['RODZAJ_SPRZEDAZY']="usługa"
    
    rejestr['PLATNOSCI'][0]['KWOTA_PLAT']=str(temp['Wartość brutto'])
    rejestr['PLATNOSCI'][0]['KWOTA_PLN_PLAT']=str(temp['Wartość brutto'])
    rejestr['PLATNOSCI'][0]['TERMIN_PLAT']=temp['Termin płatności'].strftime("%Y-%m-%d")
    rejestr['PLATNOSCI'][0]['FORMA_PLATNOSCI_PLAT']="Gotówka"

    #rejestr['PLATNOSCI'][0]['WALUTA_PLAT']=""
    #rejestr['PLATNOSCI'][0]['WALUTA_DOK']=""
    rejestr['PLATNOSCI'][0]['KIERUNEK']="przychód"

    GTU = str(temp['GTU']).split('.')
    for i in range(len(GTU)):
        if GTU[i] != 'None':
            rejestr['KODY_JPK'].append(dict({'KOD':'GTU_0'+GTU[i]}))
    
    #print(rejestr['DATA_WYSTAWIENIA'].strftime("%Y-%m-%d"))
    json_formatted_str = json.dumps(rejestr, indent=2)
    #print(json_formatted_str)
    return rejestr


class Core:
    def main(self,folderpath,fromfile):
        workbook = openpyxl.load_workbook(fromfile)
        worksheet = workbook['Sheet']
        allCells = np.array([[cell.value for cell in row] for row in worksheet.iter_rows()])
        data = []
        print(range(len(allCells[0])))
        for i in range(len(allCells[0])):
            if str(allCells[4,i]) == "Numer":
                data.append(allCells[4:-2,i])   #'Nazwa'
            if str(allCells[4,i]) == "Data wystawienia":
                data.append(allCells[4:-2,i])   #'DataWystawienia'
            if str(allCells[4,i]) == "Data sprzedaży":
                data.append(allCells[4:-2,i])   #'DataSprzedazy'
            if str(allCells[4,i]) == "Termin płatności":
                data.append(allCells[4:-2,i])   #'TerminPlatnosci'
            if str(allCells[4,i]) == "Nabywca":
                data.append(allCells[4:-2,i])   #'KontrahentNazwa'
            if str(allCells[4,i]) == "NIP":
                data.append(allCells[4:-2,i])   #'NIP'
            if str(allCells[4,i]) == "Wartość netto":
                data.append(allCells[4:-2,i])   #'Netto'
            if str(allCells[4,i]) == "Wartość VAT":
                data.append(allCells[4:-2,i])   #'Vat'
            if str(allCells[4,i]) == "Wartość brutto":
                data.append(allCells[4:-2,i])   #'Brutto'
            if str(allCells[4,i]) == "Gmina":
                data.append(allCells[4:-2,i])   #'Gmina'
            if str(allCells[4,i]) == "Adres":
                data.append(allCells[4:-2,i])   #'Adres
            if str(allCells[4,i]) == "Podzielona płatność":
                data.append(allCells[4:-2,i])   #'Splitpayment'
            if str(allCells[4,i]) == "Kwota rozliczona":
                data.append(allCells[4:-2,i])   #'KwotaRozliczona'
            if str(allCells[4,i]) == "GTU":
                data.append(allCells[4:-2,i])
        dictionary=[]
        print("elo")
        for i in range(len(data[0])):
            if i != 0:
                print(i)
                dictionary.append({data[0][0]: data[0][i], 
                            data[1][0]:data[1][i],
                            data[2][0]:data[2][i],
                            data[3][0]:data[3][i],
                            data[4][0]:data[4][i],
                            data[5][0]:data[5][i],
                            data[6][0]:data[6][i],
                            data[7][0]:data[7][i],
                            data[8][0]:data[8][i],
                            data[9][0]:data[9][i],
                            data[10][0]:data[10][i],
                            data[11][0]:data[11][i],
                            data[12][0]:data[12][i],
                            data[13][0]:data[13][i]}
                            )
        rejestry = []
        kontrahenci = []
        kontrahent={} 
        rejestr={}
        i=0
        print("elo2")
        for item in dictionary:
            i+=1
            print(i)
            rejestr=initializeR(item)
            rejestry.append(rejestr.copy())
            kontrahent=initializeK(item)
            kontrahenci.append(kontrahent.copy())
        
        ##################################################
        wersja = "2.00"
        
        #Poziom 0
        ROOT = etree.Element("ROOT",xmlns="http://www.cdn.com.pl/optima/offline")
        
        #Poziom +
        BANKI = etree.SubElement(ROOT, "BANKI")
        WERSJA = etree.SubElement(BANKI, "WERSJA")
        WERSJA.text = wersja
        BAZA_ZRD_ID = etree.SubElement(BANKI, "BAZA_ZRD_ID")
        BAZA_DOC_ID = etree.SubElement(BANKI, "BAZA_DOC_ID")
        
        #Poziom +
        KONTRAHENCI = etree.SubElement(ROOT, "KONTRAHENCI")
        WERSJA = etree.SubElement(KONTRAHENCI, "WERSJA")
        WERSJA.text = wersja
        BAZA_ZRD_ID = etree.SubElement(KONTRAHENCI, "BAZA_ZRD_ID")
        BAZA_DOC_ID = etree.SubElement(KONTRAHENCI, "BAZA_DOC_ID")
        
        for i in range(len(kontrahenci)):
        #Poziom ++
            KONTRAHENT = etree.SubElement(KONTRAHENCI, "KONTRAHENT")
            ID_ZRODLA = etree.SubElement(KONTRAHENT,"ID_ZRODLA")
            ZEZWOLENIE  = etree.SubElement(KONTRAHENT,"ZEZWOLENIE")
            OPIS = etree.SubElement(KONTRAHENT,"OPIS")
            CHRONIONY = etree.SubElement(KONTRAHENT,"CHRONIONY")
            RODZAJ  = etree.SubElement(KONTRAHENT,"RODZAJ")
            EKSPORT = etree.SubElement(KONTRAHENT,"EKSPORT")
            EKSPORT_ENOVA = etree.SubElement(KONTRAHENT,"EKSPORT_ENOVA")
            FINALNY = etree.SubElement(KONTRAHENT,"FINALNY")
            PLATNIK_VAT = etree.SubElement(KONTRAHENT,"PLATNIK_VAT")
            MEDIALNY = etree.SubElement(KONTRAHENT,"MEDIALNY")
            POWIAZANY_UOV = etree.SubElement(KONTRAHENT,"POWIAZANY_UOV")
            KATEGORIA = etree.SubElement(KONTRAHENT,"KATEGORIA")
            KATEGORIA_ID = etree.SubElement(KONTRAHENT,"KATEGORIA_ID")
            FORMA_PLATNOSCI = etree.SubElement(KONTRAHENT,"FORMA_PLATNOSCI")
            FORMA_PLATNOSCI_ID = etree.SubElement(KONTRAHENT,"FORMA_PLATNOSCI_ID")
            MAX_ZWLOKA = etree.SubElement(KONTRAHENT,"MAX_ZWLOKA")
            CENY = etree.SubElement(KONTRAHENT,"CENY")
            JEST_LIMIT_KREDYTU = etree.SubElement(KONTRAHENT,"JEST_LIMIT_KREDYTU")
            LIMIT_KREDYTU = etree.SubElement(KONTRAHENT,"LIMIT_KREDYTU")
            INFORMACJE = etree.SubElement(KONTRAHENT,"INFORMACJE")
            INDYWIDUALNY_TERMIN = etree.SubElement(KONTRAHENT,"INDYWIDUALNY_TERMIN")
            TERMIN = etree.SubElement(KONTRAHENT,"TERMIN")
        
            EKSPORT.text=kontrahenci[i]['EKSPORT']
            EKSPORT_ENOVA.text=kontrahenci[i]['EKSPORT_ENOVA']
            FINALNY.text=kontrahenci[i]['FINALNY']
            POWIAZANY_UOV.text=kontrahenci[i]['POWIAZANY_UOV']
        
        #Poziom +++
            ADRESY = etree.SubElement(KONTRAHENT,"ADRESY")
            for j in range(len(kontrahenci[i]['ADRESY'])):
                ADRES = etree.SubElement(ADRESY,"ADRES")
                STATUS = etree.SubElement(ADRES,"STATUS")
                AKRONIM = etree.SubElement(ADRES,"AKRONIM")
                EAN = etree.SubElement(ADRES,"EAN")
                GLN = etree.SubElement(ADRES,"GLN")
                NAZWA1 = etree.SubElement(ADRES,"NAZWA1")
                NAZWA2 = etree.SubElement(ADRES,"NAZWA2")
                KRAJ = etree.SubElement(ADRES,"KRAJ")
                WOJEWODZTWO = etree.SubElement(ADRES,"WOJEWODZTWO")
                POWIAT = etree.SubElement(ADRES,"POWIAT")
                GMINA = etree.SubElement(ADRES,"GMINA")
                ULICA = etree.SubElement(ADRES,"ULICA")
                NR_DOMU = etree.SubElement(ADRES,"NR_DOMU")
                NR_LOKALU = etree.SubElement(ADRES,"NR_LOKALU")
                MIASTO = etree.SubElement(ADRES,"MIASTO")
                KOD_POCZTOWY = etree.SubElement(ADRES,"KOD_POCZTOWY")
                POCZTA = etree.SubElement(ADRES,"POCZTA")
                DODATKOWE = etree.SubElement(ADRES,"DODATKOWE")
                NIP = etree.SubElement(ADRES,"NIP")
                REGON = etree.SubElement(ADRES,"REGON")
                PESEL = etree.SubElement(ADRES,"PESEL")
                TELEFON1 = etree.SubElement(ADRES,"TELEFON1")
                TELEFON2 = etree.SubElement(ADRES,"TELEFON2")
                FAX = etree.SubElement(ADRES,"FAX")
                URL = etree.SubElement(ADRES,"URL")
                EMAIL = etree.SubElement(ADRES,"EMAIL")
                BANK_NR = etree.SubElement(ADRES,"BANK_NR")
                BANK_ID = etree.SubElement(ADRES,"BANK_ID")
                NR_RACHUNKU = etree.SubElement(ADRES,"NR_RACHUNKU")
                IBAN = etree.SubElement(ADRES,"IBAN")
                
                STATUS.text=kontrahenci[i]['ADRESY'][j]['STATUS']
                AKRONIM.text=kontrahenci[i]['ADRESY'][j]['AKRONIM']
                NAZWA1.text=kontrahenci[i]['ADRESY'][j]['NAZWA1']
                KRAJ.text=kontrahenci[i]['ADRESY'][j]['KRAJ']
                WOJEWODZTWO.text=kontrahenci[i]['ADRESY'][j]['WOJEWODZTWO']
                POWIAT.text=kontrahenci[i]['ADRESY'][j]['POWIAT']
                GMINA.text=kontrahenci[i]['ADRESY'][j]['GMINA']
                ULICA.text=kontrahenci[i]['ADRESY'][j]['ULICA']
                NR_DOMU.text=kontrahenci[i]['ADRESY'][j]['NR_DOMU']
                NR_LOKALU.text=kontrahenci[i]['ADRESY'][j]['NR_LOKALU']
                MIASTO.text=kontrahenci[i]['ADRESY'][j]['MIASTO']
                KOD_POCZTOWY.text=kontrahenci[i]['ADRESY'][j]['KOD_POCZTOWY']
                POCZTA.text=kontrahenci[i]['ADRESY'][j]['POCZTA']
                NIP.text=kontrahenci[i]['ADRESY'][j]['NIP']
        
        #Poziom +++
            GRUPY = etree.SubElement(KONTRAHENT,"GRUPY")
            GRUPA = etree.SubElement(GRUPY,"GRUPA")
            NAZWA = etree.SubElement(GRUPA,"NAZWA")
            
        #Poziom +++
            PRZEDSTAWICIELE = etree.SubElement(KONTRAHENT,"BANK_NR")
            PRZEDSTAWICIEL = etree.SubElement(PRZEDSTAWICIELE, "PRZEDSTAWICIEL")
            NAZWISKO = etree.SubElement(PRZEDSTAWICIEL, "NAZWISKO")
            IMIE = etree.SubElement(PRZEDSTAWICIEL, "IMIE")
            TYTUL = etree.SubElement(PRZEDSTAWICIEL, "TYTUL")
            PLEC = etree.SubElement(PRZEDSTAWICIEL, "PLEC")
            KRAJ = etree.SubElement(PRZEDSTAWICIEL, "KRAJ")
            WOJEWODZTWO = etree.SubElement(PRZEDSTAWICIEL, "WOJEWODZTWO")
            POWIAT = etree.SubElement(PRZEDSTAWICIEL, "POWIAT")
            GMINA = etree.SubElement(PRZEDSTAWICIEL, "GMINA")
            ULICA = etree.SubElement(PRZEDSTAWICIEL, "ULICA")
            NR_DOMU = etree.SubElement(PRZEDSTAWICIEL, "NR_DOMU")
            NR_LOKALU = etree.SubElement(PRZEDSTAWICIEL, "NR_LOKALU")
            MIASTO = etree.SubElement(PRZEDSTAWICIEL, "MIASTO")
            KOD_POCZTOWY = etree.SubElement(PRZEDSTAWICIEL, "KOD_POCZTOWY")
            POCZTA = etree.SubElement(PRZEDSTAWICIEL, "POCZTA")
            DODATKOWE = etree.SubElement(PRZEDSTAWICIEL, "DODATKOWE")
            TELEFON = etree.SubElement(PRZEDSTAWICIEL, "TELEFON")
            GSM = etree.SubElement(PRZEDSTAWICIEL, "GSM")
            EMAIL = etree.SubElement(PRZEDSTAWICIEL, "EMAIL")
        
        
        
        #Poziom +
        REJESTRY_SPRZEDAZY_VAT = etree.SubElement(ROOT, "REJESTRY_SPRZEDAZY_VAT")
        WERSJA = etree.SubElement(REJESTRY_SPRZEDAZY_VAT, "WERSJA")
        WERSJA.text = wersja
        BAZA_ZRD_ID = etree.SubElement(REJESTRY_SPRZEDAZY_VAT, "BAZA_ZRD_ID")
        BAZA_DOC_ID = etree.SubElement(REJESTRY_SPRZEDAZY_VAT, "BAZA_DOC_ID")
        
        for i in range(len(rejestry)):
        #Poziom ++
            REJESTR_SPRZEDAZY_VAT = etree.SubElement(REJESTRY_SPRZEDAZY_VAT, "REJESTR_SPRZEDAZY_VAT")
            ID_ZRODLA = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "ID_ZRODLA")
            REJESTR = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "REJESTR")
            DATA_WYSTAWIENIA = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "DATA_WYSTAWIENIA")
            DATA_SPRZEDAZY = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "DATA_SPRZEDAZY")
            TERMIN = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "TERMIN")
            NUMER = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "NUMER")
            KOREKTA = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "KOREKTA")
            KOREKTA_NUMER = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "KOREKTA_NUMER")
            FISKALNA = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "FISKALNA")
            DETALICZNA = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "DETALICZNA")
            EKSPORT = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "EKSPORT")
            EKSPORT_ENOVA = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "EKSPORT_ENOVA")
            FINALNY = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "FINALNY")
            TYP_PODMIOTU = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "TYP_PODMIOTU")
            PODMIOT = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "PODMIOT")
            PODMIOT_ID = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "PODMIOT_ID")
            NAZWA1 = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "NAZWA1")
            NAZWA2 = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "NAZWA2")
            NIP = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "NIP")
            KRAJ = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "KRAJ")
            WOJEWODZTWO = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "WOJEWODZTWO")
            POWIAT = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "POWIAT")
            GMINA = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "GMINA")
            ULICA = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "ULICA")
            NR_DOMU = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "NR_DOMU")
            NR_LOKALU = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "NR_LOKALU")
            MIASTO = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "MIASTO")
            KOD_POCZTOWY = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "KOD_POCZTOWY")
            POCZTA = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "POCZTA")
            DODATKOWE = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "DODATKOWE")
            KATEGORIA = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "KATEGORIA")
            KATEGORIA_ID = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "KATEGORIA_ID")
            OPIS = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "OPIS")
            MPP = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "MPP")
            FORMA_PLATNOSCI = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "FORMA_PLATNOSCI")
            FORMA_PLATNOSCI_ID = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "FORMA_PLATNOSCI_ID")
            
            REJESTR.text=rejestry[i]['REJESTR']
            DATA_WYSTAWIENIA.text=rejestry[i]['DATA_WYSTAWIENIA']
            DATA_SPRZEDAZY.text=rejestry[i]['DATA_SPRZEDAZY']
            TERMIN.text=rejestry[i]['TERMIN']
            NUMER.text=rejestry[i]['NUMER']
            KOREKTA.text=rejestry[i]['KOREKTA']
            KOREKTA_NUMER.text=rejestry[i]['KOREKTA_NUMER']
            FISKALNA.text=rejestry[i]['FISKALNA']
            DETALICZNA.text=rejestry[i]['DETALICZNA']
            EKSPORT.text=rejestry[i]['EKSPORT']
            EKSPORT_ENOVA.text=rejestry[i]['EKSPORT_ENOVA']
            FINALNY.text=rejestry[i]['FINALNY']
            TYP_PODMIOTU.text=rejestry[i]['TYP_PODMIOTU']
            PODMIOT.text=rejestry[i]['PODMIOT']
            NAZWA1.text=rejestry[i]['NAZWA1']
            NIP.text=rejestry[i]['NIP']
            KRAJ.text=rejestry[i]['KRAJ']
            WOJEWODZTWO.text=rejestry[i]['WOJEWODZTWO']
            POWIAT.text=rejestry[i]['POWIAT']
            GMINA.text=rejestry[i]['GMINA']
            ULICA.text=rejestry[i]['ULICA']
            NR_DOMU.text=rejestry[i]['NR_DOMU']
            NR_LOKALU.text=rejestry[i]['NR_LOKALU']
            MIASTO.text=rejestry[i]['MIASTO']
            KOD_POCZTOWY.text=rejestry[i]['KOD_POCZTOWY']
            POCZTA.text=rejestry[i]['POCZTA']
            OPIS.text=rejestry[i]['OPIS']
            MPP.text=rejestry[i]['MPP']
            FORMA_PLATNOSCI.text=rejestry[i]['FORMA_PLATNOSCI']
        
            #Poziom +++
            POZYCJE = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "POZYCJE")
            for j in range(len(rejestry[i]['POZYCJE'])):
                POZYCJA = etree.SubElement(POZYCJE, "POZYCJA")
                KATEGORIA = etree.SubElement(POZYCJA, "KATEGORIA")
                KATEGORIA_ID = etree.SubElement(POZYCJA, "KATEGORIA_ID")
                STAWKA_VAT = etree.SubElement(POZYCJA, "STAWKA_VAT")
                STATUS_VAT = etree.SubElement(POZYCJA, "STATUS_VAT")
                NETTO = etree.SubElement(POZYCJA, "NETTO")
                VAT = etree.SubElement(POZYCJA, "VAT")
                NETTO_SYS = etree.SubElement(POZYCJA, "NETTO_SYS")
                VAT_SYS = etree.SubElement(POZYCJA, "VAT_SYS")
                NETTO_SYS2 = etree.SubElement(POZYCJA, "NETTO_SYS2")
                VAT_SYS2 = etree.SubElement(POZYCJA, "VAT_SYS2")
                RODZAJ_SPRZEDAZY = etree.SubElement(POZYCJA, "RODZAJ_SPRZEDAZY")
            
                STAWKA_VAT.text=rejestry[i]['POZYCJE'][j]['STAWKA_VAT']
                STATUS_VAT.text=rejestry[i]['POZYCJE'][j]['STATUS_VAT']
                NETTO.text=rejestry[i]['POZYCJE'][j]['NETTO']
                VAT.text=rejestry[i]['POZYCJE'][j]['VAT']
                NETTO_SYS.text=rejestry[i]['POZYCJE'][j]['NETTO_SYS']
                VAT_SYS.text=rejestry[i]['POZYCJE'][j]['VAT_SYS']
                NETTO_SYS2.text=rejestry[i]['POZYCJE'][j]['NETTO_SYS2']
                VAT_SYS2.text=rejestry[i]['POZYCJE'][j]['VAT_SYS2']
                RODZAJ_SPRZEDAZY.text=rejestry[i]['POZYCJE'][j]['RODZAJ_SPRZEDAZY']
        
            #Poziom +++
            PLATNOSCI = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "PLATNOSCI")
            for j in range(len(rejestry[i]['PLATNOSCI'])):
                PLATNOSC = etree.SubElement(PLATNOSCI, "PLATNOSC")
                ID_ZRODLA_PLAT = etree.SubElement(PLATNOSC, "ID_ZRODLA_PLAT")
                TERMIN_PLAT = etree.SubElement(PLATNOSC, "TERMIN_PLAT")
                FORMA_PLATNOSCI_PLAT = etree.SubElement(PLATNOSC, "FORMA_PLATNOSCI_PLAT")
                FORMA_PLATNOSCI_ID_PLAT = etree.SubElement(PLATNOSC, "FORMA_PLATNOSCI_ID_PLAT")
                KWOTA_PLAT = etree.SubElement(PLATNOSC, "KWOTA_PLAT")
                KWOTA_PLN_PLAT = etree.SubElement(PLATNOSC, "KWOTA_PLN_PLAT")
                WALUTA_PLAT = etree.SubElement(PLATNOSC, "WALUTA_PLAT")
                WALUTA_DOK = etree.SubElement(PLATNOSC, "WALUTA_DOK")
                KIERUNEK = etree.SubElement(PLATNOSC, "KIERUNEK")
        
                TERMIN_PLAT.text=rejestry[i]['PLATNOSCI'][j]['TERMIN_PLAT']
                FORMA_PLATNOSCI_PLAT.text=rejestry[i]['PLATNOSCI'][j]['FORMA_PLATNOSCI_PLAT']
                KWOTA_PLAT.text=rejestry[i]['PLATNOSCI'][j]['KWOTA_PLAT']
                KWOTA_PLN_PLAT.text=rejestry[i]['PLATNOSCI'][j]['KWOTA_PLN_PLAT']
                WALUTA_PLAT.text=rejestry[i]['PLATNOSCI'][j]['WALUTA_PLAT']
                WALUTA_DOK.text=rejestry[i]['PLATNOSCI'][j]['WALUTA_DOK']
                KIERUNEK.text=rejestry[i]['PLATNOSCI'][j]['KIERUNEK']
        
            #Poziom +++
            KODY_JPK = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "KODY_JPK")
            for j in range(len(rejestry[i]['KODY_JPK'])):
                KOD_JPK = etree.SubElement(KODY_JPK, "KOD_JPK")
                KOD = etree.SubElement(KOD_JPK, "KOD")
                KOD.text=rejestry[i]['KODY_JPK'][j]['KOD']

        xml = etree.ElementTree(ROOT)
        print('Converting OK')
        print(folderpath)
        with open(folderpath+'/KolfimetWynikowy.xml', 'wb+') as f:
            xml.write(f, xml_declaration=True, encoding='windows-1250',pretty_print=True)
        print("Kolfimet skonczone")