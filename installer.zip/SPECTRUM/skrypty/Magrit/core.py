import os
import json
from lxml import etree

def initializeK(temp):
    kontrahent = {
        'EKSPORT':"",
        'EKSPORT_ENOVA':"",
        'FINALNY':"",
        'POWIAZANY_UOV':"",
        'ADRESY':[{
            'STATUS':"",
            'AKRONIM':"",
            'NAZWA1':"",
            'KRAJ':"",
            'WOJEWODZTWO':"",
            'POWIAT':"",
            'GMINA':"",
            'ULICA':"",
            'NR_DOMU':"",
            'NR_LOKALU':"",
            'MIASTO':"",
            'KOD_POCZTOWY':"",
            'POCZTA':"",
            'NIP':""
            }
        ]
    }
    kontrahent['EKSPORT']="krajowy"
    kontrahent['EKSPORT_ENOVA']="krajowy"
    kontrahent['FINALNY']="Nie"
    kontrahent['POWIAZANY_UOV']="Nie"
    kontrahent['ADRESY'][0]['STATUS']="aktualny"
    kontrahent['ADRESY'][0]['AKRONIM']=temp['id']
    kontrahent['ADRESY'][0]['NAZWA1']=temp['nazwa']
    #kontrahent['ADRESY'][0]['KRAJ']=
    #kontrahent['ADRESY'][0]['WOJEWODZTWO']=
    #kontrahent['ADRESY'][0]['POWIAT']=
    #kontrahent['ADRESY'][0]['GMINA']=
    kontrahent['ADRESY'][0]['ULICA']=temp['ulica']
    kontrahent['ADRESY'][0]['NR_DOMU']=temp['dom'].replace(" I ",',')
    kontrahent['ADRESY'][0]['NR_LOKALU']=temp['lokal']
    kontrahent['ADRESY'][0]['MIASTO']=temp['miejscowosc']
    kontrahent['ADRESY'][0]['KOD_POCZTOWY']=temp['kodpocz']
    #kontrahent['ADRESY'][0]['POCZTA']=
    kontrahent['ADRESY'][0]['NIP']=temp['nip'].replace('-','').replace(' ','')
    return kontrahent

def initializeR(temp):
    rejestr ={
        'DATA_WYSTAWIENIA':"",
        'DATA_SPRZEDAZY':"",
        'TERMIN':"",
        'NUMER':"",
        'KOREKTA':"",
        'KOREKTA_NUMER':"",
        'FISKALNA':"",
        'DETALICZNA':"",
        'EKSPORT':"",
        'EKSPORT_ENOVA':"",
        'FINALNY':"",
        'TYP_PODMIOTU':"",
        'PODMIOT':"",
        'NAZWA1':"",
        'NIP':"",
        'KRAJ':"",
        'WOJEWODZTWO':"",
        'POWIAT':"",
        'GMINA':"",
        'ULICA':"",
        'NR_DOMU':"",
        'NR_LOKALU':"",
        'MIASTO':"",
        'KOD_POCZTOWY':"",
        'POCZTA':"",
        'OPIS':"",
        'MPP':"",
        'FORMA_PLATNOSCI':"",
        'POZYCJE':[{
            'STAWKA_VAT':"",
            'STATUS_VAT':"",
            'NETTO':"",
            'VAT':"",
            'NETTO_SYS':"",
            'VAT_SYS':"",
            'NETTO_SYS2':"",
            'VAT_SYS2':"",
            'RODZAJ_SPRZEDAZY':""
            }
        ],
        'PLATNOSCI':[{
            'TERMIN_PLAT':"",
            'FORMA_PLATNOSCI_PLAT':"",
            'KWOTA_PLAT':"",
            'KWOTA_PLN_PLAT':"",
            'WALUTA_PLAT':"",
            'WALUTA_DOK':"",
            'KIERUNEK':""
            }
        ],
        'KODY_JPK':[
        ]
    }

    #
    #rejestr = rejestr.copy()
    rejestr['DATA_WYSTAWIENIA']=temp['data']
    rejestr['DATA_SPRZEDAZY']=temp['datasp']
    rejestr['TERMIN']=temp['data']
    rejestr['NUMER']=temp['FK nazwa']
    #rejestr['KOREKTA']="Nie"
    #rejestr['KOREKTA_NUMER']=""
    #rejestr['FISKALNA']="Nie"
    #rejestr['DETALICZNA']="Nie"
    #rejestr['EKSPORT']="Nie"
    #rejestr['EKSPORT_ENOVA']="krajowy"
    #rejestr['FINALNY']="Nie"
    rejestr['TYP_PODMIOTU']="kontrahent"
    rejestr['PODMIOT']=temp['khid']
    rejestr['NIP']=temp['khnip'].replace('-','')
    rejestr['OPIS']="usługa sprzątania"
    #rejestr['MPP']="Nie"
    rejestr['FORMA_PLATNOSCI']="Gotówka"

    rejestr['POZYCJE'][0]['STATUS_VAT']="opodatkowana"
    netto = 0
    vat = 0

    for i in range(5):
        numer_rejestru='Rejestr'+str(i)
        if numer_rejestru in temp:
            if i > 0 :
                rejestr['POZYCJE'].append({
            'STAWKA_VAT':"",
            'STATUS_VAT':"",
            'NETTO':"",
            'VAT':"",
            'NETTO_SYS':"",
            'VAT_SYS':"",
            'NETTO_SYS2':"",
            'VAT_SYS2':"",
            'RODZAJ_SPRZEDAZY':""
            })
            rejestr['POZYCJE'][i]['NETTO']=temp[numer_rejestru]['netto']
            rejestr['POZYCJE'][i]['NETTO_SYS']=temp[numer_rejestru]['netto']
            rejestr['POZYCJE'][i]['NETTO_SYS2']=temp[numer_rejestru]['netto']
    
    
            rejestr['POZYCJE'][i]['VAT']=temp[numer_rejestru]['vat']
            rejestr['POZYCJE'][i]['VAT_SYS']=temp[numer_rejestru]['vat']
            rejestr['POZYCJE'][i]['VAT_SYS2']=temp[numer_rejestru]['vat']
            rejestr['POZYCJE'][i]['STAWKA_VAT']=temp[numer_rejestru]['stawka']
            rejestr['POZYCJE'][i]['RODZAJ_SPRZEDAZY']="usługa"
    
    rejestr['PLATNOSCI'][0]['KWOTA_PLAT']=temp['dozaplaty']
    rejestr['PLATNOSCI'][0]['KWOTA_PLN_PLAT']=temp['dozaplaty']       
    rejestr['PLATNOSCI'][0]['TERMIN_PLAT']=temp['plattermin']
    if temp['forma_platnosci'][0:7] == "przelew":
        rejestr['PLATNOSCI'][0]['FORMA_PLATNOSCI_PLAT']="przelew"
    else:
        rejestr['PLATNOSCI'][0]['FORMA_PLATNOSCI_PLAT']=temp['forma_platnosci']

    #rejestr['PLATNOSCI'][0]['WALUTA_PLAT']=""
    #rejestr['PLATNOSCI'][0]['WALUTA_DOK']=""
    rejestr['PLATNOSCI'][0]['KIERUNEK']="przychód"

    #GTU = temp['JPK_V7'].split(',')
    #for i in range(len(GTU)):
    #    rejestr['KODY_JPK'].append(dict({'KOD':GTU[i]}))
    

    json_formatted_str = json.dumps(rejestr, indent=2)
    print(json_formatted_str)
    return rejestr
    
    #print(json.dumps(kontrahenci,indent=3,ensure_ascii=False))
    #print(json.dumps(rejestry,indent=3,ensure_ascii=False))
    print("Initialize Ok")
    return kontrahent, rejestr
    #return kontrahenci, rejestry

def load_data(kontrahent,rejestr):
    kontrahenci=[]
    rejestry=[]

    with open("FROMJSON.txt",'r') as f:
        data = f.read()
    obj=json.loads(data)
    return kontrahenci, rejestry

class Core:
    def main(self,folderpath,fromfile):
        with open(fromfile,encoding='windows-1250') as f:
            print(fromfile)
            lines = f.read().splitlines()
        with open("skrypty/tmp/FROMJSON.txt","w+") as f:
            linetosave=""
            lastlineinf=""
            for line in lines:
                line=line.replace('""','00000')
                line=line.replace('"','\\"')
                add='",'
                if line[-1]=='=':
                    add='\",'
                if line[-1]=='{':
                    add = ''
                if line[-1]=='}':
                    add = ','
                czynowalinia=0

                if line =="Kontrahent{" or line =="Dokument{" or line =="INFO{" or line =="StawkaVAT{" or line =="Towar{" or line =="TypyCen{":
                    czynowalinia=1
                if czynowalinia == 1:
                    linetosave=linetosave.replace(",}","}")

                    if linetosave[0:12]=='"Dokument":{':
                        s=linetosave
                        pos = -1 
                        numer_rejestru=0
                        while True:
                            pos = s.find('"Rejestr":{', pos + 1)
                            if pos == -1:
                                break
                            s=s[:pos]+'"Rejestr'+str(numer_rejestru)+'":{'+s[pos+len('"Rejestr":{'):]
                            numer_rejestru=numer_rejestru+1
                        linetosave=s
                        #print(s)
                    print(linetosave[:-1],file=f)


                    #print(linetosave[:-1],file=f)
                    linetosave=""
                line=line.translate({ord('{'):'":{'})
                line=line.replace(" =", '":"')
                line=line.replace("\\@", '/')
                line=line.strip()
                line=line.split("\t")
                if line[-1]!='}':
                    tmp='"'+line[-1]
                else:
                    tmp=line[-1]
                linetosave=linetosave+tmp+add
                lastlineinf=tmp+add
        with open("skrypty/tmp/FROMJSON.txt",'r') as f:
            datas = f.read().splitlines()
            i=0
            for data in datas:
                i+=1
                print(i)
                if not data:
                    pass
                else:
                    #print(data[0:12])
                    #print(data[0:14])
                    if data[0:7]=='"INFO":':
                        #print('INFO')
                        obj=json.loads(data[7:])
                        #print(obj)
                    if data[0:12]=='"Dokument":{':
                        #print("Dokument")
                        obj=json.loads(data[11:])
                    if data[0:14]=='"Kontrahent":{':
                        #print(data[13:])
                        obj=json.loads(data[13:])
        print('skonczone')
##################################################
        rejestry = []
        kontrahenci = []
        
        kontrahent={} 
        rejestr={}
        
        
        with open("skrypty/tmp/FROMJSON.txt",'r') as f:
            datas = f.read().splitlines()
            i=0
            for data in datas:
                i+=1
                print(i)
                if not data:
                    pass
                else:
                    if data[0:12]=='"Dokument":{':
                        obj=json.loads(data[11:])
                        #if obj['Opis FK']=="Magazyn":
                        #    print("magazyn")
                        #else:
                        #    print("niemagazyn")
                        rejestr=initializeR(obj)
                        rejestry.append(rejestr.copy())
                    if data[0:14]=='"Kontrahent":{':
                        obj=json.loads(data[13:])
                        kontrahent=initializeK(obj)
                        kontrahenci.append(kontrahent.copy())
        
        
        #kontrahenci, rejestry = load_data(kontrahent,rejestr)
        
##################################################
        wersja = "2.00"
        
        #Poziom 0
        ROOT = etree.Element("ROOT",xmlns="http://www.cdn.com.pl/optima/offline")
        
        #Poziom +
        BANKI = etree.SubElement(ROOT, "BANKI")
        WERSJA = etree.SubElement(BANKI, "WERSJA")
        WERSJA.text = wersja
        BAZA_ZRD_ID = etree.SubElement(BANKI, "BAZA_ZRD_ID")
        BAZA_DOC_ID = etree.SubElement(BANKI, "BAZA_DOC_ID")
        
        #Poziom +
        KONTRAHENCI = etree.SubElement(ROOT, "KONTRAHENCI")
        WERSJA = etree.SubElement(KONTRAHENCI, "WERSJA")
        WERSJA.text = wersja
        BAZA_ZRD_ID = etree.SubElement(KONTRAHENCI, "BAZA_ZRD_ID")
        BAZA_DOC_ID = etree.SubElement(KONTRAHENCI, "BAZA_DOC_ID")
        
        for i in range(len(kontrahenci)):
        #Poziom ++
            KONTRAHENT = etree.SubElement(KONTRAHENCI, "KONTRAHENT")
            ID_ZRODLA = etree.SubElement(KONTRAHENT,"ID_ZRODLA")
            ZEZWOLENIE  = etree.SubElement(KONTRAHENT,"ZEZWOLENIE")
            OPIS = etree.SubElement(KONTRAHENT,"OPIS")
            CHRONIONY = etree.SubElement(KONTRAHENT,"CHRONIONY")
            RODZAJ  = etree.SubElement(KONTRAHENT,"RODZAJ")
            EKSPORT = etree.SubElement(KONTRAHENT,"EKSPORT")
            EKSPORT_ENOVA = etree.SubElement(KONTRAHENT,"EKSPORT_ENOVA")
            FINALNY = etree.SubElement(KONTRAHENT,"FINALNY")
            PLATNIK_VAT = etree.SubElement(KONTRAHENT,"PLATNIK_VAT")
            MEDIALNY = etree.SubElement(KONTRAHENT,"MEDIALNY")
            POWIAZANY_UOV = etree.SubElement(KONTRAHENT,"POWIAZANY_UOV")
            KATEGORIA = etree.SubElement(KONTRAHENT,"KATEGORIA")
            KATEGORIA_ID = etree.SubElement(KONTRAHENT,"KATEGORIA_ID")
            FORMA_PLATNOSCI = etree.SubElement(KONTRAHENT,"FORMA_PLATNOSCI")
            FORMA_PLATNOSCI_ID = etree.SubElement(KONTRAHENT,"FORMA_PLATNOSCI_ID")
            MAX_ZWLOKA = etree.SubElement(KONTRAHENT,"MAX_ZWLOKA")
            CENY = etree.SubElement(KONTRAHENT,"CENY")
            JEST_LIMIT_KREDYTU = etree.SubElement(KONTRAHENT,"JEST_LIMIT_KREDYTU")
            LIMIT_KREDYTU = etree.SubElement(KONTRAHENT,"LIMIT_KREDYTU")
            INFORMACJE = etree.SubElement(KONTRAHENT,"INFORMACJE")
            INDYWIDUALNY_TERMIN = etree.SubElement(KONTRAHENT,"INDYWIDUALNY_TERMIN")
            TERMIN = etree.SubElement(KONTRAHENT,"TERMIN")
        
            EKSPORT.text=kontrahenci[i]['EKSPORT']
            EKSPORT_ENOVA.text=kontrahenci[i]['EKSPORT_ENOVA']
            FINALNY.text=kontrahenci[i]['FINALNY']
            POWIAZANY_UOV.text=kontrahenci[i]['POWIAZANY_UOV']
        
        #Poziom +++
            ADRESY = etree.SubElement(KONTRAHENT,"ADRESY")
            for j in range(len(kontrahenci[i]['ADRESY'])):
                ADRES = etree.SubElement(ADRESY,"ADRES")
                STATUS = etree.SubElement(ADRES,"STATUS")
                AKRONIM = etree.SubElement(ADRES,"AKRONIM")
                EAN = etree.SubElement(ADRES,"EAN")
                GLN = etree.SubElement(ADRES,"GLN")
                NAZWA1 = etree.SubElement(ADRES,"NAZWA1")
                NAZWA2 = etree.SubElement(ADRES,"NAZWA2")
                KRAJ = etree.SubElement(ADRES,"KRAJ")
                WOJEWODZTWO = etree.SubElement(ADRES,"WOJEWODZTWO")
                POWIAT = etree.SubElement(ADRES,"POWIAT")
                GMINA = etree.SubElement(ADRES,"GMINA")
                ULICA = etree.SubElement(ADRES,"ULICA")
                NR_DOMU = etree.SubElement(ADRES,"NR_DOMU")
                NR_LOKALU = etree.SubElement(ADRES,"NR_LOKALU")
                MIASTO = etree.SubElement(ADRES,"MIASTO")
                KOD_POCZTOWY = etree.SubElement(ADRES,"KOD_POCZTOWY")
                POCZTA = etree.SubElement(ADRES,"POCZTA")
                DODATKOWE = etree.SubElement(ADRES,"DODATKOWE")
                NIP = etree.SubElement(ADRES,"NIP")
                REGON = etree.SubElement(ADRES,"REGON")
                PESEL = etree.SubElement(ADRES,"PESEL")
                TELEFON1 = etree.SubElement(ADRES,"TELEFON1")
                TELEFON2 = etree.SubElement(ADRES,"TELEFON2")
                FAX = etree.SubElement(ADRES,"FAX")
                URL = etree.SubElement(ADRES,"URL")
                EMAIL = etree.SubElement(ADRES,"EMAIL")
                BANK_NR = etree.SubElement(ADRES,"BANK_NR")
                BANK_ID = etree.SubElement(ADRES,"BANK_ID")
                NR_RACHUNKU = etree.SubElement(ADRES,"NR_RACHUNKU")
                IBAN = etree.SubElement(ADRES,"IBAN")
                
                STATUS.text=kontrahenci[i]['ADRESY'][j]['STATUS']
                AKRONIM.text=kontrahenci[i]['ADRESY'][j]['AKRONIM']
                NAZWA1.text=kontrahenci[i]['ADRESY'][j]['NAZWA1']
                KRAJ.text=kontrahenci[i]['ADRESY'][j]['KRAJ']
                WOJEWODZTWO.text=kontrahenci[i]['ADRESY'][j]['WOJEWODZTWO']
                POWIAT.text=kontrahenci[i]['ADRESY'][j]['POWIAT']
                GMINA.text=kontrahenci[i]['ADRESY'][j]['GMINA']
                ULICA.text=kontrahenci[i]['ADRESY'][j]['ULICA']
                NR_DOMU.text=kontrahenci[i]['ADRESY'][j]['NR_DOMU']
                NR_LOKALU.text=kontrahenci[i]['ADRESY'][j]['NR_LOKALU']
                MIASTO.text=kontrahenci[i]['ADRESY'][j]['MIASTO']
                KOD_POCZTOWY.text=kontrahenci[i]['ADRESY'][j]['KOD_POCZTOWY']
                POCZTA.text=kontrahenci[i]['ADRESY'][j]['POCZTA']
                NIP.text=kontrahenci[i]['ADRESY'][j]['NIP']
        
        #Poziom +++
            GRUPY = etree.SubElement(KONTRAHENT,"GRUPY")
            GRUPA = etree.SubElement(GRUPY,"GRUPA")
            NAZWA = etree.SubElement(GRUPA,"NAZWA")
            
        #Poziom +++
            PRZEDSTAWICIELE = etree.SubElement(KONTRAHENT,"BANK_NR")
            PRZEDSTAWICIEL = etree.SubElement(PRZEDSTAWICIELE, "PRZEDSTAWICIEL")
            NAZWISKO = etree.SubElement(PRZEDSTAWICIEL, "NAZWISKO")
            IMIE = etree.SubElement(PRZEDSTAWICIEL, "IMIE")
            TYTUL = etree.SubElement(PRZEDSTAWICIEL, "TYTUL")
            PLEC = etree.SubElement(PRZEDSTAWICIEL, "PLEC")
            KRAJ = etree.SubElement(PRZEDSTAWICIEL, "KRAJ")
            WOJEWODZTWO = etree.SubElement(PRZEDSTAWICIEL, "WOJEWODZTWO")
            POWIAT = etree.SubElement(PRZEDSTAWICIEL, "POWIAT")
            GMINA = etree.SubElement(PRZEDSTAWICIEL, "GMINA")
            ULICA = etree.SubElement(PRZEDSTAWICIEL, "ULICA")
            NR_DOMU = etree.SubElement(PRZEDSTAWICIEL, "NR_DOMU")
            NR_LOKALU = etree.SubElement(PRZEDSTAWICIEL, "NR_LOKALU")
            MIASTO = etree.SubElement(PRZEDSTAWICIEL, "MIASTO")
            KOD_POCZTOWY = etree.SubElement(PRZEDSTAWICIEL, "KOD_POCZTOWY")
            POCZTA = etree.SubElement(PRZEDSTAWICIEL, "POCZTA")
            DODATKOWE = etree.SubElement(PRZEDSTAWICIEL, "DODATKOWE")
            TELEFON = etree.SubElement(PRZEDSTAWICIEL, "TELEFON")
            GSM = etree.SubElement(PRZEDSTAWICIEL, "GSM")
            EMAIL = etree.SubElement(PRZEDSTAWICIEL, "EMAIL")
        
        
        
        #Poziom +
        REJESTRY_SPRZEDAZY_VAT = etree.SubElement(ROOT, "REJESTRY_SPRZEDAZY_VAT")
        WERSJA = etree.SubElement(REJESTRY_SPRZEDAZY_VAT, "WERSJA")
        WERSJA.text = wersja
        BAZA_ZRD_ID = etree.SubElement(REJESTRY_SPRZEDAZY_VAT, "BAZA_ZRD_ID")
        BAZA_DOC_ID = etree.SubElement(REJESTRY_SPRZEDAZY_VAT, "BAZA_DOC_ID")
        
        for i in range(len(rejestry)):
        #Poziom ++
            REJESTR_SPRZEDAZY_VAT = etree.SubElement(REJESTRY_SPRZEDAZY_VAT, "REJESTR_SPRZEDAZY_VAT")
            ID_ZRODLA = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "ID_ZRODLA")
            REJESTR = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "REJESTR")
            DATA_WYSTAWIENIA = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "DATA_WYSTAWIENIA")
            DATA_SPRZEDAZY = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "DATA_SPRZEDAZY")
            TERMIN = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "TERMIN")
            NUMER = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "NUMER")
            KOREKTA = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "KOREKTA")
            KOREKTA_NUMER = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "KOREKTA_NUMER")
            FISKALNA = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "FISKALNA")
            DETALICZNA = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "DETALICZNA")
            EKSPORT = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "EKSPORT")
            EKSPORT_ENOVA = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "EKSPORT_ENOVA")
            FINALNY = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "FINALNY")
            TYP_PODMIOTU = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "TYP_PODMIOTU")
            PODMIOT = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "PODMIOT")
            PODMIOT_ID = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "PODMIOT_ID")
            NAZWA1 = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "NAZWA1")
            NAZWA2 = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "NAZWA2")
            NIP = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "NIP")
            KRAJ = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "KRAJ")
            WOJEWODZTWO = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "WOJEWODZTWO")
            POWIAT = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "POWIAT")
            GMINA = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "GMINA")
            ULICA = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "ULICA")
            NR_DOMU = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "NR_DOMU")
            NR_LOKALU = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "NR_LOKALU")
            MIASTO = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "MIASTO")
            KOD_POCZTOWY = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "KOD_POCZTOWY")
            POCZTA = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "POCZTA")
            DODATKOWE = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "DODATKOWE")
            KATEGORIA = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "KATEGORIA")
            KATEGORIA_ID = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "KATEGORIA_ID")
            OPIS = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "OPIS")
            MPP = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "MPP")
            FORMA_PLATNOSCI = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "FORMA_PLATNOSCI")
            FORMA_PLATNOSCI_ID = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "FORMA_PLATNOSCI_ID")
            
            DATA_WYSTAWIENIA.text=rejestry[i]['DATA_WYSTAWIENIA']
            DATA_SPRZEDAZY.text=rejestry[i]['DATA_SPRZEDAZY']
            TERMIN.text=rejestry[i]['TERMIN']
            NUMER.text=rejestry[i]['NUMER']
            KOREKTA.text=rejestry[i]['KOREKTA']
            KOREKTA_NUMER.text=rejestry[i]['KOREKTA_NUMER']
            FISKALNA.text=rejestry[i]['FISKALNA']
            DETALICZNA.text=rejestry[i]['DETALICZNA']
            EKSPORT.text=rejestry[i]['EKSPORT']
            EKSPORT_ENOVA.text=rejestry[i]['EKSPORT_ENOVA']
            FINALNY.text=rejestry[i]['FINALNY']
            TYP_PODMIOTU.text=rejestry[i]['TYP_PODMIOTU']
            PODMIOT.text=rejestry[i]['PODMIOT']
            NAZWA1.text=rejestry[i]['NAZWA1']
            NIP.text=rejestry[i]['NIP']
            KRAJ.text=rejestry[i]['KRAJ']
            WOJEWODZTWO.text=rejestry[i]['WOJEWODZTWO']
            POWIAT.text=rejestry[i]['POWIAT']
            GMINA.text=rejestry[i]['GMINA']
            ULICA.text=rejestry[i]['ULICA']
            NR_DOMU.text=rejestry[i]['NR_DOMU']
            NR_LOKALU.text=rejestry[i]['NR_LOKALU']
            MIASTO.text=rejestry[i]['MIASTO']
            KOD_POCZTOWY.text=rejestry[i]['KOD_POCZTOWY']
            POCZTA.text=rejestry[i]['POCZTA']
            OPIS.text=rejestry[i]['OPIS']
            MPP.text=rejestry[i]['MPP']
            FORMA_PLATNOSCI.text=rejestry[i]['FORMA_PLATNOSCI']
        
            #Poziom +++
            POZYCJE = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "POZYCJE")
            for j in range(len(rejestry[i]['POZYCJE'])):
                POZYCJA = etree.SubElement(POZYCJE, "POZYCJA")
                KATEGORIA = etree.SubElement(POZYCJA, "KATEGORIA")
                KATEGORIA_ID = etree.SubElement(POZYCJA, "KATEGORIA_ID")
                STAWKA_VAT = etree.SubElement(POZYCJA, "STAWKA_VAT")
                STATUS_VAT = etree.SubElement(POZYCJA, "STATUS_VAT")
                NETTO = etree.SubElement(POZYCJA, "NETTO")
                VAT = etree.SubElement(POZYCJA, "VAT")
                NETTO_SYS = etree.SubElement(POZYCJA, "NETTO_SYS")
                VAT_SYS = etree.SubElement(POZYCJA, "VAT_SYS")
                NETTO_SYS2 = etree.SubElement(POZYCJA, "NETTO_SYS2")
                VAT_SYS2 = etree.SubElement(POZYCJA, "VAT_SYS2")
                RODZAJ_SPRZEDAZY = etree.SubElement(POZYCJA, "RODZAJ_SPRZEDAZY")
            
                STAWKA_VAT.text=rejestry[i]['POZYCJE'][j]['STAWKA_VAT']
                STATUS_VAT.text=rejestry[i]['POZYCJE'][j]['STATUS_VAT']
                NETTO.text=rejestry[i]['POZYCJE'][j]['NETTO']
                VAT.text=rejestry[i]['POZYCJE'][j]['VAT']
                NETTO_SYS.text=rejestry[i]['POZYCJE'][j]['NETTO_SYS']
                VAT_SYS.text=rejestry[i]['POZYCJE'][j]['VAT_SYS']
                NETTO_SYS2.text=rejestry[i]['POZYCJE'][j]['NETTO_SYS2']
                VAT_SYS2.text=rejestry[i]['POZYCJE'][j]['VAT_SYS2']
                RODZAJ_SPRZEDAZY.text=rejestry[i]['POZYCJE'][j]['RODZAJ_SPRZEDAZY']
        
            #Poziom +++
            PLATNOSCI = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "PLATNOSCI")
            for j in range(len(rejestry[i]['PLATNOSCI'])):
                PLATNOSC = etree.SubElement(PLATNOSCI, "PLATNOSC")
                ID_ZRODLA_PLAT = etree.SubElement(PLATNOSC, "ID_ZRODLA_PLAT")
                TERMIN_PLAT = etree.SubElement(PLATNOSC, "TERMIN_PLAT")
                FORMA_PLATNOSCI_PLAT = etree.SubElement(PLATNOSC, "FORMA_PLATNOSCI_PLAT")
                FORMA_PLATNOSCI_ID_PLAT = etree.SubElement(PLATNOSC, "FORMA_PLATNOSCI_ID_PLAT")
                KWOTA_PLAT = etree.SubElement(PLATNOSC, "KWOTA_PLAT")
                KWOTA_PLN_PLAT = etree.SubElement(PLATNOSC, "KWOTA_PLN_PLAT")
                WALUTA_PLAT = etree.SubElement(PLATNOSC, "WALUTA_PLAT")
                WALUTA_DOK = etree.SubElement(PLATNOSC, "WALUTA_DOK")
                KIERUNEK = etree.SubElement(PLATNOSC, "KIERUNEK")
        
                TERMIN_PLAT.text=rejestry[i]['PLATNOSCI'][j]['TERMIN_PLAT']
                FORMA_PLATNOSCI_PLAT.text=rejestry[i]['PLATNOSCI'][j]['FORMA_PLATNOSCI_PLAT']
                KWOTA_PLAT.text=rejestry[i]['PLATNOSCI'][j]['KWOTA_PLAT']
                KWOTA_PLN_PLAT.text=rejestry[i]['PLATNOSCI'][j]['KWOTA_PLN_PLAT']
                WALUTA_PLAT.text=rejestry[i]['PLATNOSCI'][j]['WALUTA_PLAT']
                WALUTA_DOK.text=rejestry[i]['PLATNOSCI'][j]['WALUTA_DOK']
                KIERUNEK.text=rejestry[i]['PLATNOSCI'][j]['KIERUNEK']
        
            #Poziom +++
            KODY_JPK = etree.SubElement(REJESTR_SPRZEDAZY_VAT, "KODY_JPK")
            for j in range(len(rejestry[i]['KODY_JPK'])):
                KOD_JPK = etree.SubElement(KODY_JPK, "KOD_JPK")
                KOD = etree.SubElement(KOD_JPK, "KOD")
                KOD.text=rejestry[i]['KODY_JPK'][j]['KOD']
        
        
        xml = etree.ElementTree(ROOT)
        print('Converting OK')
        with open(folderpath+'/MagritWynikowy.xml', 'wb+') as f:
            xml.write(f, xml_declaration=True, encoding='windows-1250',pretty_print=True)
        print ('Magrit skonczone')