__version__ = 1.0


from PyQt5 import QtWidgets, uic
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5.QtWidgets import QFileDialog, QMessageBox, QPushButton
import os
import importlib.util
import urllib.request
import webbrowser




class TextView(QtWidgets.QTextEdit):
    def __init__(self,parent=None):
        super(TextView, self).__init__(parent)
        self.setGeometry(9, 110, 353, 33)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.accept()
        else:
            event.ignore()

    def dropEvent(self, event):
        files = [u.toLocalFile() for u in event.mimeData().urls()]
        for f in files:
            self.setText(f)



class mainProgram(QtWidgets.QMainWindow):
    def __init__(self):
        super(mainProgram, self).__init__()
        uic.loadUi('untitled.ui', self)
        self.setWindowTitle("SPECTRUM Konwerter v."+str(__version__))
        self.BTN_Convert.clicked.connect(self.convert)
        self.BTN_ConvertEX.clicked.connect(self.convertEX)
        self.BTN_ConvertEXXML.clicked.connect(self.convertEXXML)
        self.BTN_Exit.clicked.connect(self.close)
        self.BTN_Browse.clicked.connect(self.getfiles)
        self.textEdit=TextView(self.centralwidget)
        
        self.setAcceptDrops(True)
        self.show()

        VersionFromGit=urllib.request.urlopen('https://raw.githubusercontent.com/sniezeek/SPECTRUM/main/version').read()
        if float(VersionFromGit)>float(__version__):
            msg = QMessageBox()
            msg.addButton("Tak", QMessageBox.YesRole)
            msg.addButton("Nie", QMessageBox.NoRole)
            msg.setText("Stara wersja programu ("+str(__version__)+"<"+str(float(VersionFromGit))+"), Czy ściągnąć nową?", )
            msg.setWindowTitle("Aktualizacja")
            ret=msg.exec_()
            if ret==0:
                print('stara version')
                webbrowser.open_new_tab('https://github.com/sniezeek/SPECTRUM/raw/main/installer.zip')
        else:
            print('nowa wersion')


    def convert(self):

        spec = importlib.util.spec_from_file_location("module.name","skrypty/"+self.comboBox.currentText()+"/"+"core.py")
        foo = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(foo)
        folderpath = QtWidgets.QFileDialog.getExistingDirectory(self, 'Select Folder')
        print(folderpath)
        try:
            if folderpath!='':
                for fromfile in self.textEdit.toPlainText().splitlines( ): #self.filenames:

                    foo.Core.main(foo.Core,folderpath,fromfile)
                msg = QMessageBox()
                msg.setWindowTitle("Info")
                msg.setText("Konwersja Udana")
                x = msg.exec_()
        except Exception as e:
            msg = QMessageBox()
            msg.setWindowTitle("Info")
            msg.setText("Brak pliku wejsciowego")
            print(e)
            x = msg.exec_()
    
    def convertEX(self):
        print("s")

    def convertEXXML(self):
        print("s")

    def getfiles(self):
        newWindow=QFileDialog()
        newWindow.setFileMode(QFileDialog.ExistingFiles)
        if newWindow.exec_():
            self.filenames = newWindow.selectedFiles()
            self.textEdit.setText(str("\n".join(self.filenames)))


    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.accept()
        else:
            event.ignore()

    def dropEvent(self, event):
        files = [u.toLocalFile() for u in event.mimeData().urls()]
        for f in files:
            self.textEdit.setText(f)


if __name__ == "__main__":
    import sys
    try:
        app = QtWidgets.QApplication(sys.argv)
        window = mainProgram()
        sys.exit(app.exec_())
    except Exception as e:
      print("Erorr to : %s", e)